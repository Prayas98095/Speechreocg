# speechrecon
Minor Project on Speech Recognition
